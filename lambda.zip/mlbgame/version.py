#!/usr/bin/env python

# package version
__version__ = '2.4.2'
"""Installed version of mlbgame."""
